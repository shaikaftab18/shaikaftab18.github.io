A simple rock-paper-scissors game using HTML CSS amd JS using math.random function and three buttons
The game consists of you vs computer and the score along with it counting wins,loses,ties and these are stored using the localstorage 
Output:
![image](https://github.com/shaikaftab18/rock-paper-scissors-game/assets/107014967/37c7ec81-f341-4aef-8077-b729fc197591)

